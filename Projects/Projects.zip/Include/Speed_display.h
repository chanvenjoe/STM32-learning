#ifndef _SPEED_DISPLAY
#define _SPEED_DISPLAY

#define u8 unsigned char
#define u16 unsigned int

void numb_show(u16 n);
void digitron_init(void);
#endif

#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long
void Timer0_Delay125ns(u32 u32CNT);
void Timer0_Delay100us(u32 u32CNT);
void Timer0_Delay1ms(u32 u32CNT);
void Timer1_Delay10ms(u32 u32CNT);
void Timer2_Delay500us(u32 u32CNT);
void Timer3_Delay100ms(u32 u32CNT);

void Timer0_Delay40ms(u32 u32CNT);
void Timer3_Delay10us(u32 u32CNT);
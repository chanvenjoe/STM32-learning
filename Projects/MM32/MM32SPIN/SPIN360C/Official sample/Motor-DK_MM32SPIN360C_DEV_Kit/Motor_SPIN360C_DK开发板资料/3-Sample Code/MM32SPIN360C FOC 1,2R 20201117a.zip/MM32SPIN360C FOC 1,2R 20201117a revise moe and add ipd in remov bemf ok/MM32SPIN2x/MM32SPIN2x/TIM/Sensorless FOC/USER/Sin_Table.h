
#ifndef __SIN_TABLE_H
#define __SIN_TABLE_H

extern const int16_t s16SinTable[]; 
extern const unsigned char Hall_correction0[];
extern const unsigned char Hall_correction1[];

#endif



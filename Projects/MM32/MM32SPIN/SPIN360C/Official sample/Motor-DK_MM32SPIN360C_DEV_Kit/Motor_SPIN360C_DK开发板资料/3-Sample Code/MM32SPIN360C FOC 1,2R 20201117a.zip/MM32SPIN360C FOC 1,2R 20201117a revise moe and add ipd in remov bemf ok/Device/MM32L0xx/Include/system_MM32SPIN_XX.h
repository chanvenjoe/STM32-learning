#ifndef __SYSTEM_MM32SPINXX_H__
#define __SYSTEM_MM32SPINXX_H__
extern uint32_t SystemCoreClock;
void SystemInit (void);

#endif


#ifndef __PI_H
#define __PI_H

#include "sys.h"

#define SMO_PLL_SPEED_Ki_MULTIPLY 16// 2//8//20191213
#define SPEED_Ki_MULTIPLY         16
#define CURRENT_Ki_MULTIPLY       512
#define MTPA_FW_Id_Ki_MULTIPLY    16//20200303
#define DECOUPLING_CONTROL_Iq_Ki_MULTIPLY    512//20200522
#define DECOUPLING_CONTROL_Id_Ki_MULTIPLY    512//20200522

typedef struct {

	int32_t s32ErrorOld;
	int32_t s32IntegralResult;
	int32_t s32KpQ15,s32KiQ15;
	int32_t s32PIOutputLimit;
	int32_t s32IntegralResultLimit;
}PI_Struct;

int16_t PI_control_speed(int16_t s16Error, PI_Struct* C);
int16_t PI_control_current(int16_t s16Error, PI_Struct* C);
int16_t PI_control_PLL_estimated_speed(int16_t s16Error, PI_Struct* C);//20191213
int16_t PI_control_MTPA_FW_estimated_Id(int16_t s16Error, PI_Struct* C);//20200303
int16_t PI_control_current_decoupling(int16_t s16Error, PI_Struct* C);//20200522
#endif

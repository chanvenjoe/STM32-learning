/**
******************************************************************************
* @file    pwm.c  
* @brief   ���ö�ʱ��TIM1,PA8\PA9\PA10\PB13\PB14\PB15���6·PWM����
******************************************************************************
*/

/* Includes ------------------------------------------------------------------*/
#include "delay.h"
#include "pwm.h" 
#include "led.h"
#include "adc.h"
#include "sys.h"
#include "Whole_Motor_Parameters.h"
#include "HAL_conf.h"
//#include "HAL_rcc.h"
//#include "HAL_gpio.h"
#include "HAL_comp.h"
//#include "comp.h"

/*��ӦPWM����ܽ�
PA08->TIM1_CH1,CH1�������
PA09->TIM1_CH2,CH2�������
PA10->TIM1_CH3,CH3�������
PB13->TIM1_CH1N,CH1�������
PB14->TIM1_CH2N,CH2�������
PB15->TIM1_CH3N,CH3�������
*/
//Ƶ��=(48*1000000/(999+1))*(0+1)=48KHz Period=999, Prescaler=0
//PWM�����ʼ��
//Period���Զ���װֵ
//Prescaler��ʱ��Ԥ��Ƶ��

__IO uint32_t u32DMAtoT1CC1[2];	
__IO uint32_t u32DMAtoT1CC2[2];	
__IO uint32_t u32DMAtoT1CC3[2];	
__IO int32_t  s32DMAtoADDRx[3];
__IO uint32_t u32DMAtoT3CC1[2];

extern __IO uint32_t u32DMA1ShuntRADCCHAddress;

void NVIC_Configuration4TTIM1(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_UP_TRG_COM_IRQn;
	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
	NVIC_InitStructure.NVIC_IRQChannelPriority = 0x1;//0:highest priority, 3:lowest priority
	#else
	NVIC_InitStructure.NVIC_IRQChannelPriority = 0x0;//0:highest priority, 3:lowest priority
	#endif
	
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
}	

#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
void NVIC_Configuration4TTIM3(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;	
	NVIC_InitStructure.NVIC_IRQChannelPriority = 0x0;//0:highest priority, 3:lowest priority	
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
	NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
}	
#endif

#ifdef ENABLE_OVER_CURRENT_TIM1BKIN_PROTECTION //enable this to do over current protection (PWM OFF), if comparator output Low signal
#ifdef ENABLE_TIM1BKIN_PIN_EXTERNAL_INPUT
void TIM1_BKIN_External_Input_Pin_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);  		//����GPIOBʱ��
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_12; 				    //PB12=TIM1_BKIN
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IN_FLOATING;  //��������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  GPIO_PinAFConfig(GPIOB,GPIO_PinSource12,GPIO_AF_2);
}
#endif
#endif

void TIM1_PWM_Init(uint16_t u16Period,uint16_t u16Prescaler,uint8_t u8DeadTime)
{  
  GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;  
	
	#ifdef ENABLE_SPIN2X
		RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA| RCC_AHBPeriph_GPIOB , ENABLE);//GPIOA,GPIOB����ʱ��ʹ�� 
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE); //TIM1����ʱ��ʹ�� 
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;//TIM1_CH3N���
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		
		//TIM1_CH1,TIM1_CH1N,TIM1_CH2,TIM1_CH2N,TIM1_CH3���
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_4|GPIO_Pin_3;
		
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //�����������
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
		GPIO_Init(GPIOB, &GPIO_InitStructure); 	
		
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource7,GPIO_AF_7);//TIM1_CH1//GPIO�˿ڸ��ù���ʹ��
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource6,GPIO_AF_7);//TIM1_CH1N//GPIO�˿ڸ��ù���ʹ��
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource5,GPIO_AF_7);//TIM1_CH2//GPIO�˿ڸ��ù���ʹ��
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource4,GPIO_AF_7);//TIM1_CH2N//GPIO�˿ڸ��ù���ʹ��
		GPIO_PinAFConfig(GPIOB, GPIO_PinSource3,GPIO_AF_7);//TIM1_CH3//GPIO�˿ڸ��ù���ʹ��
		GPIO_PinAFConfig(GPIOA, GPIO_PinSource15,GPIO_AF_7);//TIM1_CH3N//GPIO�˿ڸ��ù���ʹ��
	#endif
	
//	TIM_Cmd(TIM1, ENABLE);  //ʹ��TIM1��ʼ����
//  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  TIM_TimeBaseStructure.TIM_Period = u16Period; //��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ	
	TIM_TimeBaseStructure.TIM_Prescaler =u16Prescaler; //����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ  ����Ƶ
	TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_CenterAligned2;//for ADC trigger use in period interrupt, TIM_CounterMode_Up;
	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
		 #ifdef ENABLE_LEFT_HALF_PWM_GET_IaIbIc_1_SHUNT_R //20190108
			TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_CenterAligned2;//for ADC trigger, TIM up count effective, TIM_CounterMode_Up(for left half pwm to get phase current)
		 #else
			TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_CenterAligned1;//for ADC trigger, TIM Down count effective, TIM_CounterMode_down(for right half pwm to get phase current)
		 #endif
	#endif
	
	
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //����ʱ�ӷָ�:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 1; //�ظ���������0 = Update Event at every overflow
	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
	 #ifdef ENABLE_LEFT_HALF_PWM_GET_IaIbIc_1_SHUNT_R //20190108
	 	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; //�ظ���������0 = Update Event at every overflow, and use software check DIR==1 or not
	 #endif
	#endif
	
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);  //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
	
	TIM_OCStructInit(&TIM_OCInitStructure); //��ʼ��TIM_OCInitStructure
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //CH1�Ƚ����ʹ��		
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //CH1N�Ƚ����ʹ��	
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //CH1�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High; //CH1N�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set; //CH1�������״̬:1	
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset; //CH1N�������״̬:0		

	TIM_OCInitStructure.TIM_Pulse = u16Period>>1;//���ô�װ�벶��ȽϼĴ���������ֵ
	TIM_OC1Init(TIM1, &TIM_OCInitStructure);  //CH1,CH1N����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIM1
	TIM_OCInitStructure.TIM_Pulse = u16Period>>1;//���ô�װ�벶��ȽϼĴ���������ֵ
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);  //CH2,CH2N����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIM1
	TIM_OCInitStructure.TIM_Pulse = u16Period>>1;//���ô�װ�벶��ȽϼĴ���������ֵ
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);  //CH3,CH3N����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIM1	
	
	/* Divided clock for TIM1*/
	TIM1->PSC = 0x00;  // CLK = HSI/(0+1) = 48MHz/1 = 48MHz	
  
	#ifdef ENABLE_OVER_CURRENT_TIM1BKIN_PROTECTION   //enable this to do over current protection (PWM OFF), if comparator output Low signal
		{
			TIM_BDTRInitTypeDef TIM_BDTRInitStruct;

			TIM_BDTRInitStruct.TIM_OSSRState = TIM_OSSRState_Disable;//TIM_OSSRState_Enable;//����ģʽ�¹ر�״̬ѡ��
			TIM_BDTRInitStruct.TIM_OSSIState = TIM_OSSIState_Disable;//TIM_OSSIState_Enable;//����ģʽ�¹ر�״̬ѡ��
			TIM_BDTRInitStruct.TIM_LOCKLevel = TIM_LOCKLevel_OFF;//����������������:�����ر��ޱ���
			TIM_BDTRInitStruct.TIM_DeadTime  = u8DeadTime;//DTG[7:0]��������������:(����ʱ��DT)
			TIM_BDTRInitStruct.TIM_Break     = TIM_Break_Enable;//TIM_Break_Disable;//TIM_Break_Enable;  //ɲ�����ã�ʹ��ɲ��
			TIM_BDTRInitStruct.TIM_BreakPolarity   = BREAK_POLARITY;//TIM_BreakPolarity_High;//TIM_BreakPolarity_Low;//ɲ�����뼫��ѡ��
			TIM_BDTRInitStruct.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;//TIM_AutomaticOutput_Enable;//�Զ����ʹ������:MOEֻ��������1
			TIM_BDTRConfig( TIM1, &TIM_BDTRInitStruct); //���û����������ʱ��   
		}
  #else
		/* Dead Time Setting */
		TIM1->BDTR |= 0x00|u8DeadTime; // Setting Dead Time [7:0] = 0x30 = 1us at 48MHz
	#endif
//--------------------------------------------------------------------------------------------------------------------------------	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
		TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Disable );  //Disable Preload, CCR will be updated right away when new value be written.
		TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Disable );  //Disable Preload, CCR will be updated right away when new value be written.
		TIM_OC3PreloadConfig(TIM1,TIM_OCPreload_Disable );  //Disable Preload, CCR will be updated right away when new value be written.
		
		TIM_ARRPreloadConfig(TIM1, ENABLE);    //ʹ��TIM1��ARR�ϵ�Ԥװ�ؼĴ���	
		
		#ifdef ENABLE_OVER_CURRENT_TIM1BKIN_PROTECTION  
			TIM_ITConfig(TIM1, TIM_IT_Update | TIM_IT_Break , ENABLE);   
			TIM_ClearITPendingBit(TIM1, TIM_IT_Break | TIM_FLAG_Update);	
		#else
			TIM_ITConfig(TIM1, TIM_IT_Update, ENABLE);  // Enable TIM1 Update Event Interrupt
		#endif
		
		NVIC_Configuration4TTIM1();
	#endif
//--------------------------------------------------------------------------------------------------------------------------------
  #ifndef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
	TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable );  //ʹ���Զ�װ��
	TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Enable );  //ʹ���Զ�װ��
	TIM_OC3PreloadConfig(TIM1,TIM_OCPreload_Enable );  //ʹ���Զ�װ��
	
	TIM_ARRPreloadConfig(TIM1, ENABLE);    //ʹ��TIM1��ARR�ϵ�Ԥװ�ؼĴ���	
	
	#ifdef ENABLE_OVER_CURRENT_TIM1BKIN_PROTECTION  
    TIM_ITConfig(TIM1, TIM_IT_Break , ENABLE);   
	  TIM_ClearITPendingBit(TIM1, TIM_IT_Break | TIM_FLAG_Update);	
	#endif
	
	NVIC_Configuration4TTIM1();
	
	TIM1->BDTR |= 0x8000; // �����ʹ��	
	#endif
}

void Enable_Motor1_TIM1_PWM_Break(void)//20200710
{
	TIM_BDTRInitTypeDef TIM_BDTRInitStruct;
	TIM_BDTRInitStruct.TIM_OSSRState = TIM_OSSRState_Disable;//TIM_OSSRState_Enable;//����ģʽ�¹ر�״̬ѡ��
	TIM_BDTRInitStruct.TIM_OSSIState = TIM_OSSIState_Disable;//TIM_OSSIState_Enable;//����ģʽ�¹ر�״̬ѡ��
	TIM_BDTRInitStruct.TIM_LOCKLevel = TIM_LOCKLevel_OFF;//����������������:�����ر��ޱ���
	TIM_BDTRInitStruct.TIM_DeadTime  = DEAD_TIME_SETUP;//DTG[7:0]��������������:(����ʱ��DT)
	TIM_BDTRInitStruct.TIM_Break     = TIM_Break_Enable;//TIM_Break_Disable;//TIM_Break_Enable;  //ɲ�����ã�ʹ��ɲ��
	TIM_BDTRInitStruct.TIM_BreakPolarity   = BREAK_POLARITY;//TIM_BreakPolarity_High;//TIM_BreakPolarity_Low;//ɲ�����뼫��ѡ��
	TIM_BDTRInitStruct.TIM_AutomaticOutput = TIM_AutomaticOutput_Disable;//TIM_AutomaticOutput_Enable;//�Զ����ʹ������:MOEֻ��������1
	TIM_BDTRConfig( TIM1, &TIM_BDTRInitStruct); //���û����������ʱ�� 
}


void Enable_Motor1_PWM_Output(void)//PWM�_ʼ�黥�a
{
	TIM_CtrlPWMOutputs(TIM1, ENABLE);      //ʹ��TIM1 PWM�����������	
//	TIM1->CCMR1=0x6868;   // Output keep PWM1 mode (CH2/CH1)
//	TIM1->CCMR2=0x0068;   // Output keep PWM1 mode (CH4/CH3)
//	TIM1->CCER =0x0555;   // D:CCxNP=0/CCxNE=1/CCxP=0/CCxE=1 
//	TIM1->EGR =0x0020;    // Active immediately : PWM is complementary type and H_side = High active L_side = High active                    
}

void Disable_Motor1_PWM_Output(void)//�Уף��P�]�飰ݔ��
{
	TIM_CtrlPWMOutputs(TIM1, DISABLE);      //Disable TIM1 PWM�����������	
//	TIM1->CCMR1=0x5858;   // Output keep OCREF=1 (CH2/CH1)
//	TIM1->CCMR2=0x0058;   // Output keep OCREF=1 (CH4/CH3)
//	TIM1->CCER =0x0CCC;   // D:CCxNP=1/CCxNE=1/CCxP=0/CCxE=0 
//	TIM1->EGR =0x0020;    // Active immediately : H_side = 0, Low_side = 0                
}


/* TIM3 Initialize */
#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
void TIM3_PWM_Init(uint16_t u16Period,uint16_t u16Prescaler)
{  
	//GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;  	
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	
	//RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB , ENABLE);//GPIOA,GPIOB����ʱ��ʹ�� 	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;//TIM3_CH1���, PB4
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //�����������
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
//	GPIO_Init(GPIOB, &GPIO_InitStructure); 
//	GPIO_PinAFConfig(GPIOB, GPIO_PinSource4,GPIO_AF_1);//GPIO�˿ڸ��ù���ʹ��
	
	
	TIM_TimeBaseStructure.TIM_Period=u16Period;                                                                      //ARR�Ĵ���ֵ
	TIM_TimeBaseStructure.TIM_Prescaler=u16Prescaler;                                                                //Ԥ��Ƶֵ
	/*�����˲�������Ƶ��,��Ӱ�춨ʱ��ʱ��*/
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;                                                         //������Ƶֵ
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_CenterAligned1;                                         //����ģʽ
	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
		 #ifdef ENABLE_LEFT_HALF_PWM_GET_IaIbIc_1_SHUNT_R //20190108
			TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_CenterAligned2;//for ADC trigger, TIM up count effective, TIM_CounterMode_Up(for left half pwm to get phase current)
		 #else
			TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_CenterAligned1;//for ADC trigger, TIM Down count effective, TIM_CounterMode_down(for right half pwm to get phase current)
		 #endif
	#endif
	
	
	TIM_TimeBaseStructure.TIM_RepetitionCounter=1;
	
	#ifdef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
	 #ifdef ENABLE_LEFT_HALF_PWM_GET_IaIbIc_1_SHUNT_R //20190108
	 	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; //�ظ���������0 = Update Event at every overflow, and use software check DIR==1 or not
	 #endif
	#endif
	
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	/* TIM3 need to be symmetric by TIM1 */
	TIM_SelectOutputTrigger(TIM1, TIM_TRGOSource_Enable);
	TIM_SelectInputTrigger(TIM3, TIM_TS_ITR0);  // TIM_TS_ITR0 = Symmetric by TIM1
	TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_Gated);
	TIM_SelectMasterSlaveMode(TIM3, TIM_MasterSlaveMode_Enable);

	TIM_OCStructInit(&TIM_OCInitStructure); //��ʼ��TIM_OCInitStructure
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //CH1�Ƚ����ʹ��		
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //CH1N�Ƚ����ʹ��	
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //CH1�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High; //CH1N�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set; //CH1�������״̬:1	
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset; //CH1N�������״̬:0		

	TIM_OCInitStructure.TIM_Pulse = u16Period>>1; // Close to center value
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);   //CH1,CH1N����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIM1
	
	/* Divided clock for TIM1*/
	TIM3->PSC = 0x00;  // CLK = HSI/(0+1) = 48MHz/1 = 48MHz	
  TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Disable );//Disable Preload, CCR will be updated right away when new value be written.
	TIM_ARRPreloadConfig(TIM3, ENABLE);    //ʹ��TIM3��ARR�ϵ�Ԥװ�ؼĴ���		
	TIM_CtrlPWMOutputs(TIM3, ENABLE);
	
	#ifdef ENABLE_SPIN2X
  /* Enable DMA of TIM3 */
	TIM_DMACmd(TIM3,TIM_DMA_CC1,ENABLE);
//  TIM_DMACmd(TIM3,TIM_DMA_Update,ENABLE);
	/* Enable UDE Interrupt of TIM3 */
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);  // Enable TIM3 Update Event Interrupt
	NVIC_Configuration4TTIM3();
  #endif
	
	/* Must Enable TIM1, TIM3 Simultaneously */
	TIM_Cmd(TIM3, ENABLE);//TIM3 Controlled by TIM1
	TIM_Cmd(TIM1, ENABLE);//Must Enable TIM1, TIM3 Simultaneously 
}
#endif

#ifndef ENABLE_1_SHUNT_R_TO_MEASURE_3_PHASE_CURRENT
void TIM3_PWM_Init(uint16_t u16Period,uint16_t u16Prescaler)
{  
//	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;  	
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	
//	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA , ENABLE);//GPIOA,GPIOB����ʱ��ʹ�� 	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;//TIM3_CH1���
//	
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; //�����������
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
//	GPIO_Init(GPIOA, &GPIO_InitStructure); 
//	
//	GPIO_PinAFConfig(GPIOA, GPIO_PinSource6,GPIO_AF_1);//GPIO�˿ڸ��ù���ʹ��
	
	TIM_TimeBaseStructure.TIM_Period=u16Period;                                                                      //ARR�Ĵ���ֵ
	TIM_TimeBaseStructure.TIM_Prescaler=u16Prescaler;                                                                //Ԥ��Ƶֵ
	/*�����˲�������Ƶ��,��Ӱ�춨ʱ��ʱ��*/
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;                                                         //������Ƶֵ
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_CenterAligned2;                                         //����ģʽ
	TIM_TimeBaseStructure.TIM_RepetitionCounter=0;
	
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	/* TIM3 need to be symmetric by TIM1 */
	TIM_SelectOutputTrigger(TIM1, TIM_TRGOSource_Enable);
	TIM_SelectInputTrigger(TIM3, TIM_TS_ITR0);  // TIM_TS_ITR0 = Symmetric by TIM1
	TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_Gated);
	TIM_SelectMasterSlaveMode(TIM3, TIM_MasterSlaveMode_Enable);

	TIM_OCStructInit(&TIM_OCInitStructure); //��ʼ��TIM_OCInitStructure
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ2
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //CH1�Ƚ����ʹ��		
	TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable; //CH1N�Ƚ����ʹ��	
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //CH1�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High; //CH1N�������:TIM����Ƚϼ��Ը�	
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set; //CH1�������״̬:1	
	TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset; //CH1N�������״̬:0		

	TIM_OCInitStructure.TIM_Pulse = 5; // Close to center value
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);   //CH1,CH1N����TIM_OCInitStruct��ָ���Ĳ�����ʼ������TIM1
	
	/* Divided clock for TIM1*/
	TIM3->PSC = 0x00;  // CLK = HSI/(0+1) = 48MHz/1 = 48MHz	 	
	TIM_OC1PreloadConfig(TIM3,TIM_OCPreload_Enable );  //ʹ���Զ�װ��	
	TIM_ARRPreloadConfig(TIM3, ENABLE);    //ʹ��TIM3��ARR�ϵ�Ԥװ�ؼĴ���		
	TIM_CtrlPWMOutputs(TIM3, ENABLE);
  
	/* Must Enable TIM1, TIM3 Simultaneously */
	TIM_Cmd(TIM3, ENABLE);//TIM3 Controlled by TIM1
	TIM_Cmd(TIM1, ENABLE);//Must Enable TIM1, TIM3 Simultaneously 
}
#endif

#ifdef ENABLE_SPIN2X
void Init_OP_Amplifier(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_OPAMP, ENABLE); //enable OP Amplifier clock

  // internal OP1
	#ifdef ENABLE_OP1_PA4_PA5_PA6    //PA6  output has connect to SPIN2X internal ADC pin 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);  	
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_4; // PA4/PA5/PA6
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	OPAMP->CSR |= 0x00000001;//enable OP1
  #endif
	
  // internal OP2
	#ifdef ENABLE_OP2_PB0_PB1_PB2    //PB2  output has connect to SPIN2X internal ADC pin 
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE); 
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_2|GPIO_Pin_1|GPIO_Pin_0; 			
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	OPAMP->CSR |= 0x00000100;//enable OP2
  #endif
	
  // internal OP3
  #ifdef ENABLE_OP3_PB12_PB11_PB10 //PB10 output has connect to SPIN2X internal ADC pin
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);  
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_12|GPIO_Pin_11|GPIO_Pin_10; 	
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	OPAMP->CSR |= 0x00010000;//enable OP3
  #endif

  // internal OP4
	#ifdef ENABLE_OP4_PB15_PA8_PA9   //PA9  output has not connect to SPIN2X internal ADC pin
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);  	
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9|GPIO_Pin_8; 			
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  	
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE); 
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_15; 		
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	OPAMP->CSR |= 0x01000000;//enable OP4
  #endif
	
	delay_ms(30);//wait OP Output stable.
	
//	#ifdef ENABLE_OP1_PA4_PA5_PA6
//	OPAMP->CSR |= 0x00000001;
//	#endif
//	
//	#ifdef ENABLE_OP2_PB0_PB1_PB2    //PB2  output has connect to SPIN2X internal ADC pin 
//	OPAMP->CSR |= 0x00000100;
//	#endif
//	
//  #ifdef ENABLE_OP3_PB12_PB11_PB10
//	OPAMP->CSR |= 0x00010000;
//	#endif
//	
//	#ifdef ENABLE_OP4_PB15_PA8_PA9 
//	OPAMP->CSR |= 0x01000000;
//	#endif
	
  //OPAMP->CSR = 0x01010101;		// OP1 OP2 OP3 OP4�Ƅ�
}

#endif


#ifdef ENABLE_OVER_CURRENT_COMP1_PROTECTION
/*

+--------------------------------------------------+     
|                 |                | COMP1 | COMP2 |  
|-----------------|----------------|---------------|
|                 | 1/4 VREFINT    |  OK   |  OK   | 
|                 | 1/2 VREFINT    |  OK   |  OK   |
|                 | 3/4 VREFINT    |  OK   |  OK   | 
| Inverting Input | VREFINT        |  OK   |  OK   | 
|                 | DAC1 OUT (PA4) |  OK   |  OK   | 
|                 | DAC2 OUT (PA5) |  OK   |  OK   |  
|                 | IO1            |  PA0  |  PA2  | 
|                 | IO2            |  PA6  |  PA6  |  
|-----------------|----------------|-------|-------|
|  Non Inverting  | IO1            |  PA0  |  PA0  | 
|    Input        | IO2            |  PA1  |  PA1  | 
|    		      | IO3            |  PA2  |  PA2  |
|    		      | IO4            |  PA3  |  PA3  |
|    		      | IO5            |  PA4  |  PA4  | 
|    		      | IO6            |  PA5  |  PA5  |
|    		      | IO7            |  PA6  |  PA6  |
|    		      | IO8            |  PA7  |  PA7  |
+--------------------------------------------------+  

*/

#ifdef ENABLE_SPIN2X
void Init_Comparator(void)
{ 
		GPIO_InitTypeDef GPIO_InitStructure;
		COMP_InitTypeDef COMP_InitStructure;

		//GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_11; 		// PA11-PA12
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11; 		// PA11
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;//GPIO_Mode_IN_FLOATING;//GPIO_Mode_AIN;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		//GPIO_PinAFConfig(GPIOA,GPIO_PinSource11,GPIO_AF_0);
		//GPIO_PinAFConfig(GPIOA,GPIO_PinSource12,GPIO_AF_0);

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_CPT, ENABLE); 

		COMP_DeInit(COMP_Selection_COMP5);
		COMP_InitStructure.COMP_InvertingInput    = COMP_InvertingInput_CRV;//COMP_InvertingInput_CRV;//COMP_InvertingInput_IO2;
		COMP_InitStructure.COMP_NonInvertingInput = COMP_NonInvertingInput_IO1;	//for PA11
		COMP_InitStructure.COMP_Output            = COMP_Output_TIM1BKIN;//COMP_Output_TIM1BKIN;//COMP_Output_None;
		COMP_InitStructure.COMP_OutputPol         = COMP_OutputPol_NonInverted;//COMP_OutputPol_Inverted;//COMP_OutputPol_NonInverted;
		COMP_InitStructure.COMP_Hysteresis        = COMP_Hysteresis_Medium;//COMP_Hysteresis_Low;//COMP_Hysteresis_No;
		COMP_InitStructure.COMP_Mode              = COMP_Mode_MediumSpeed;//COMP_Mode_MediumSpeed;//COMP_Mode_UltraLowPower;
		COMP_InitStructure.COMP_Filter            = COMP_Filter_32_Period;//COMP_Filter_64_Period;

		COMP_Init(COMP_Selection_COMP5, &COMP_InitStructure);

		//ADC_TempSensorCmd(ENABLE);//for enable internal 1.2V vref 
  #if 0
		ADC_VrefintCmd(ENABLE);
		SET_COMP_CRV(cHardCurrentVref, cHardCurrent);
  #else
		SET_COMP_CRV(COMP_CRV_Sele_AVDD, INTERNAL_COMPARATOR_INM_REF_CRV_VOLTAGE);//(3_24) real is 1/20 of 5V = 0.25V,(6_24) real is 4/20 of 5V = 1V
  #endif

  COMP_Cmd(COMP_Selection_COMP5, ENABLE);
#endif

}
#endif


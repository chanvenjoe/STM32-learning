/**************************************************************************//**
* @file HAL_device.h
* @brief CMSIS Cortex-M Peripheral Access Layer for MindMotion
*        microcontroller devices
*
* This is a convenience header file for defining the part number on the
* build command line, instead of specifying the part specific header file.
*
* Example: Add "-DMM32SPIN_XX" to your build options, to define part
*          Add "#include "HAL_device.h" to your source files
*
*
* @version 1.0.0
*
*
*****************************************************************************/

#ifndef __HAL_device_H
#define __HAL_device_H

#define  MM32SPIN_XX

#if defined(MM32L072PF)

#include "MM32L072PF.h"
//#include "system_MM32L072PF.h"

#elif defined(MM32SPIN_XX)
//#error  dontwantincludethisfile
#include "MM32SPIN_XX.h"
#include "system_MM32SPIN_XX.h"

#elif defined(MM32X031)
#include "MM32X031.h"
//#include "system_MM32X031.h"

#else
#error "HAL_device.h: PART NUMBER undefined"
#endif
#endif /* __HAL_device_H */
/*-------------------------(C) COPYRIGHT 2016 MindMotion ----------------------*/

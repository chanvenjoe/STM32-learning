#ifndef __PWR_PVD_H
#define __PWR_PVD_H 
#include "HAL_conf.h"

void PVD_EXTI_Init( void );

#endif

#ifndef		_TIME_ISP_H_
#define		_TIME_ISP_H_

void TIME2_ISP_INIT(void);
extern	unsigned char TIM2_100ms_count;



#endif
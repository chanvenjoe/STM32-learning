#ifndef		_GPRS_H_
#define		_GPRS_H_


#define AT_ORDER  1
#define DATA	  2

void M26_POW_ON(void);
void M26_handler(void);




#endif
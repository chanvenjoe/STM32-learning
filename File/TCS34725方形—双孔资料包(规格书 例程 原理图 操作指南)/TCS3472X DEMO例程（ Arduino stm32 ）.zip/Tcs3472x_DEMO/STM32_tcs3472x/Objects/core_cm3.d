.\objects\core_cm3.o: startup\core_cm3.c
.\objects\core_cm3.o: D:\Program Files (tech)\KeilMdk\ARM\ARMCC\Bin\..\include\stdint.h
